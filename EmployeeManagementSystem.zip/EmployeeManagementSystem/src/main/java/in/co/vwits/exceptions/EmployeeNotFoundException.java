package in.co.vwits.exceptions;

public class EmployeeNotFoundException extends Exception{
	
}
